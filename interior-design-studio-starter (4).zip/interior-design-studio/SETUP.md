# Interior Design Studio — setup and free deployment

This is a custom React portfolio website with a public gallery and a protected admin area.

## What is included
- Public portfolio with room-category filters.
- Admin email/password login.
- Admin-only photo uploads and project deletion.
- Supabase database and Storage policies that enforce admin-only writes.
- Responsive layout for mobile and desktop.

## 1. Create your Supabase backend
1. Create a free project at https://supabase.com/.
2. Open **SQL Editor** in your Supabase dashboard.
3. Paste and run all contents of `supabase-setup.sql`.
4. Open **Project Settings → API** (or **Data API / API Keys**, depending on dashboard version).
5. Copy the Project URL and the publishable/anon key. The browser key is intended to be public; NEVER put a `service_role` or secret key in this website.

## 2. Create your admin login
1. In Supabase, open **Authentication → Users** and add a user with your own email and a strong password. Disable public sign-ups in Authentication settings if that option is enabled.
2. Copy the user's UUID.
3. In SQL Editor, run this command after replacing the placeholder:
   `insert into public.admin_users (user_id) values ('YOUR-ADMIN-USER-UUID');`
4. Do not add any other user IDs to `admin_users`. Only IDs in this table can upload, edit or delete.

## 3. Run the website locally (optional)
1. Install Node.js LTS from https://nodejs.org/.
2. Extract this project folder and open a terminal in it.
3. Run `npm install`.
4. Copy `.env.example` to `.env` and fill in:
   - `VITE_SUPABASE_URL` = your Supabase Project URL
   - `VITE_SUPABASE_ANON_KEY` = your Supabase publishable/anon key
5. Run `npm run dev` and open the local address printed in the terminal.

## 4. Publish a free public website link with Vercel
1. Create a free account at https://vercel.com/.
2. Create a GitHub account at https://github.com/ if you do not already have one.
3. Create a new GitHub repository and upload the extracted project files.
4. In Vercel, choose **Add New → Project**, import that repository.
5. Framework preset: Vite. Build command: `npm run build`. Output directory: `dist`.
6. In Vercel project **Settings → Environment Variables**, add:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
   Use the same values from Supabase. Do not add a service-role key.
7. Deploy. Vercel will provide a public `*.vercel.app` link that anyone can open in a browser.
8. After changing environment variables, redeploy.

## 5. Use your site
- Everyone can open the Vercel link and view the portfolio.
- Open the same link and choose **Admin** in the top-right corner to sign in.
- After login, upload a photo, choose its room type, add a title and description, and publish.
- Only the admin UUID allow-listed in Supabase can upload, edit or delete. Public visitors have read-only access.

## Before sharing
- Replace the sample email link `hello@interiordesignstudio.example` in `src/App.jsx` with your real business email.
- Replace the sample hero/about photos if you prefer your own brand imagery.
- Test the site in a private/incognito browser window to confirm public visitors can view photos but cannot access admin controls.
- Keep your admin password private and enable email confirmation / strong password settings where available.

## Important notes
- The project includes three sample gallery images until you connect Supabase. They are demo images from Unsplash.
- This is a starter website, not yet deployed. You must create the Supabase project and Vercel deployment to receive your own public link.
- Free-plan limits and features can change. Check current provider pricing and quotas before relying on them for a business-critical site.
