-- Run this entire script in Supabase Dashboard > SQL Editor.
-- It creates public project records, an admin allow-list and secure storage policies.

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade
);

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  category text not null,
  description text default '',
  image_url text not null,
  storage_path text,
  created_at timestamptz not null default now()
);

alter table public.admin_users enable row level security;
alter table public.projects enable row level security;

-- Public visitors can view published portfolio entries.
drop policy if exists "Projects are viewable by everyone" on public.projects;
create policy "Projects are viewable by everyone"
on public.projects for select using (true);

-- Only IDs explicitly placed in admin_users can create, edit or delete projects.
drop policy if exists "Admins can insert projects" on public.projects;
create policy "Admins can insert projects"
on public.projects for insert to authenticated
with check (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));

drop policy if exists "Admins can update projects" on public.projects;
create policy "Admins can update projects"
on public.projects for update to authenticated
using (exists (select 1 from public.admin_users a where a.user_id = auth.uid()))
with check (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));

drop policy if exists "Admins can delete projects" on public.projects;
create policy "Admins can delete projects"
on public.projects for delete to authenticated
using (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));

-- Admin allow-list is private; each signed-in user can only verify their own membership. No client-side insert/update/delete policies are provided.
drop policy if exists "No client access to admin list" on public.admin_users;
create policy "Admins can verify their own membership"
on public.admin_users for select to authenticated using (user_id = auth.uid());

-- Create a PUBLIC bucket named interior-photos in Storage.
insert into storage.buckets (id, name, public)
values ('interior-photos', 'interior-photos', true)
on conflict (id) do update set public = true;

-- Anyone can view image files; only allow-listed admins can upload/change/delete.
drop policy if exists "Public can view interior photos" on storage.objects;
create policy "Public can view interior photos"
on storage.objects for select using (bucket_id = 'interior-photos');

drop policy if exists "Admins can upload interior photos" on storage.objects;
create policy "Admins can upload interior photos"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'interior-photos'
  and exists (select 1 from public.admin_users a where a.user_id = auth.uid())
);

drop policy if exists "Admins can update interior photos" on storage.objects;
create policy "Admins can update interior photos"
on storage.objects for update to authenticated
using (
  bucket_id = 'interior-photos'
  and exists (select 1 from public.admin_users a where a.user_id = auth.uid())
)
with check (
  bucket_id = 'interior-photos'
  and exists (select 1 from public.admin_users a where a.user_id = auth.uid())
);

drop policy if exists "Admins can delete interior photos" on storage.objects;
create policy "Admins can delete interior photos"
on storage.objects for delete to authenticated
using (
  bucket_id = 'interior-photos'
  and exists (select 1 from public.admin_users a where a.user_id = auth.uid())
);

-- After creating your admin user in Supabase Authentication > Users,
-- copy that user's UUID and run this separately:
-- insert into public.admin_users (user_id) values ('PASTE-ADMIN-USER-UUID-HERE');