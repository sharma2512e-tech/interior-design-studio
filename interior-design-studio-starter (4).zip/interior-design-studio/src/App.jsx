import React, { useEffect, useMemo, useState } from 'react';
import { ArrowDown, ArrowUpRight, Instagram, Menu, X, LockKeyhole, Plus, Trash2, LogOut, ImagePlus, LoaderCircle, CheckCircle2 } from 'lucide-react';
import { isConfigured, supabase } from './supabase';

const categories = ['All spaces', 'Living room', 'Bedroom', 'Kitchen', 'Bathroom', 'Office', 'Other'];
const demoProjects = [
  {id:'demo-1', title:'Quiet luxury living', category:'Living room', description:'Warm textures, natural light and a calm, welcoming palette.', image_url:'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1400&q=85'},
  {id:'demo-2', title:'A softer retreat', category:'Bedroom', description:'A restful bedroom layered with tactile, natural materials.', image_url:'https://images.unsplash.com/photo-1616594039964-ae9021a400a0?auto=format&fit=crop&w=1400&q=85'},
  {id:'demo-3', title:'The everyday kitchen', category:'Kitchen', description:'Simple lines and thoughtful details made for daily life.', image_url:'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1400&q=85'}
];

export default function App() {
  const [projects, setProjects] = useState([]);
  const [filter, setFilter] = useState('All spaces');
  const [loading, setLoading] = useState(true);
  const [adminOpen, setAdminOpen] = useState(false);
  const [session, setSession] = useState(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Living room');
  const [description, setDescription] = useState('');
  const [photo, setPhoto] = useState(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');

  async function loadProjects() {
    if (!isConfigured) { setProjects(demoProjects); setLoading(false); return; }
    const { data, error } = await supabase.from('projects').select('*').order('created_at', { ascending: false });
    if (error) setNotice(error.message);
    else setProjects(data || []);
    setLoading(false);
  }

  useEffect(() => {
    loadProjects();
    if (!isConfigured) return;
    supabase.auth.getSession().then(({data}) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => listener.subscription.unsubscribe();
  }, []);

  const shownProjects = useMemo(() => projects.filter(p => filter === 'All spaces' || p.category === filter), [projects, filter]);

  async function signIn(e) {
    e.preventDefault(); setBusy(true); setNotice('');
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setBusy(false); setNotice(error ? error.message : 'Signed in successfully.');
  }
  async function signOut() {
    await supabase.auth.signOut(); setNotice('You have signed out.');
  }
  async function addProject(e) {
    e.preventDefault();
    if (!photo) { setNotice('Please choose a photo first.'); return; }
    setBusy(true); setNotice('');
    const ext = photo.name.split('.').pop().toLowerCase().replace(/[^a-z0-9]/g, '') || 'jpg';
    const path = `${crypto.randomUUID()}.${ext}`;
    const upload = await supabase.storage.from('interior-photos').upload(path, photo, { upsert: false, contentType: photo.type });
    if (upload.error) { setBusy(false); setNotice(upload.error.message); return; }
    const { data: publicData } = supabase.storage.from('interior-photos').getPublicUrl(path);
    const { error } = await supabase.from('projects').insert({
      title: title.trim(), category, description: description.trim(),
      image_url: publicData.publicUrl, storage_path: path
    });
    setBusy(false);
    if (error) {
      await supabase.storage.from('interior-photos').remove([path]);
      setNotice(error.message);
    } else {
      setTitle(''); setDescription(''); setPhoto(null);
      document.getElementById('photo-input') && (document.getElementById('photo-input').value = '');
      setNotice('Your project is now published.'); await loadProjects();
    }
  }
  async function deleteProject(project) {
    if (!window.confirm(`Delete “${project.title}”?`)) return;
    setBusy(true);
    if (project.storage_path) await supabase.storage.from('interior-photos').remove([project.storage_path]);
    const { error } = await supabase.from('projects').delete().eq('id', project.id);
    setBusy(false); setNotice(error ? error.message : 'Project deleted.'); if (!error) loadProjects();
  }

  return <div className="site">
    <header className="topbar">
      <a className="brand" href="#home"><span className="brand-mark">IDS</span><span>INTERIOR DESIGN<br/><small>STUDIO</small></span></a>
      <nav><a href="#work">Our work</a><a href="#about">Approach</a><a href="#contact">Contact</a></nav>
      <button className="admin-link" onClick={() => {setAdminOpen(true); setNotice('');}}><LockKeyhole size={15}/> Admin</button>
    </header>

    <main>
      <section className="hero" id="home">
        <div className="hero-copy">
          <p className="eyebrow">SPACES THAT FEEL LIKE YOU</p>
          <h1>Thoughtful spaces.<br/><em>Beautifully lived.</em></h1>
          <p className="hero-text">We create considered interiors that bring ease, warmth and quiet character to everyday living.</p>
          <a className="text-link" href="#work">Explore our work <ArrowDown size={16}/></a>
        </div>
        <div className="hero-image"><img src="https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1800&q=90" alt="Warm, elegant contemporary living room"/><span className="image-note">A HOME, MADE PERSONAL — 01</span></div>
        <div className="hero-index">EST. WITH INTENTION <span>CHENNAI · INDIA</span></div>
      </section>

      <section className="work-section" id="work">
        <div className="section-head"><div><p className="eyebrow">SELECTED INTERIORS</p><h2>Spaces with a story.</h2></div><p className="section-intro">A collection of rooms shaped around the way people live, gather and unwind.</p></div>
        <div className="filters">{categories.map(c => <button key={c} className={filter===c?'active':''} onClick={()=>setFilter(c)}>{c}</button>)}</div>
        {loading ? <div className="loading"><LoaderCircle className="spin"/> Loading projects…</div> :
          shownProjects.length ? <div className="project-grid">{shownProjects.map((p,i)=><article className={`project-card card-${i%3}`} key={p.id}>
            <div className="project-image"><img src={p.image_url} alt={p.title}/><span className="project-arrow"><ArrowUpRight/></span></div>
            <div className="project-meta"><div><p className="eyebrow">{p.category}</p><h3>{p.title}</h3><p className="project-description">{p.description}</p></div><span className="project-number">{String(i+1).padStart(2,'0')}</span></div>
          </article>)}</div> : <div className="empty">No projects in this category yet. Please check back soon.</div>}
      </section>

      <section className="about-section" id="about">
        <div className="about-image"><img src="https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1400&q=85" alt="Natural materials and warm minimalist interior"/></div>
        <div className="about-copy"><p className="eyebrow">OUR APPROACH</p><h2>Less, but with<br/><em>more meaning.</em></h2><p>Good design is not about filling a room. It is about understanding what matters, choosing with care and creating a space that feels naturally yours.</p><a className="text-link" href="#contact">Let’s create something <ArrowUpRight size={16}/></a></div>
      </section>

      <section className="contact-section" id="contact"><p className="eyebrow">HAVE A SPACE IN MIND?</p><h2>Let’s make room<br/><em>for living.</em></h2><p>Tell us a little about your project. We’d love to hear from you.</p><a className="contact-link" href="mailto:hello@interiordesignstudio.example">Start a conversation <ArrowUpRight size={17}/></a></section>
    </main>
    <footer><a className="brand footer-brand" href="#home"><span className="brand-mark">IDS</span><span>INTERIOR DESIGN<br/><small>STUDIO</small></span></a><span>Thoughtfully designed. Beautifully lived.</span><span>© {new Date().getFullYear()} Interior Design Studio</span></footer>

    {adminOpen && <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)setAdminOpen(false)}}><section className="admin-modal">
      <button className="close-modal" onClick={()=>setAdminOpen(false)} aria-label="Close"><X/></button>
      <p className="eyebrow">PRIVATE AREA</p><h2>Studio admin</h2>
      {!isConfigured ? <div className="setup-warning"><strong>Website setup needed</strong><p>Connect your Supabase project by adding its URL and public anon/publishable key to the deployment environment variables. See SETUP.md in the project folder.</p></div> :
        !session ? <form className="admin-form" onSubmit={signIn}><label>Email address<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required autoComplete="username"/></label><label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required autoComplete="current-password"/></label><button className="primary-button" disabled={busy}>{busy?'Signing in…':'Sign in'}</button></form> :
        <><div className="signed-in"><CheckCircle2 size={17}/> Signed in as {session.user.email}<button onClick={signOut}><LogOut size={15}/> Sign out</button></div>
          <form className="admin-form" onSubmit={addProject}>
            <label>Project name<input value={title} onChange={e=>setTitle(e.target.value)} required maxLength="90" placeholder="e.g. Calm coastal apartment"/></label>
            <label>Room type<select value={category} onChange={e=>setCategory(e.target.value)}>{categories.filter(c=>c!=='All spaces').map(c=><option key={c}>{c}</option>)}</select></label>
            <label>Short description<textarea value={description} onChange={e=>setDescription(e.target.value)} rows="3" maxLength="240" placeholder="A few words about this space…"/></label>
            <label className="file-picker"><ImagePlus size={20}/><span>{photo ? photo.name : 'Choose an image (JPG, PNG or WebP)'}</span><input id="photo-input" type="file" accept="image/jpeg,image/png,image/webp" onChange={e=>setPhoto(e.target.files?.[0]||null)} required/></label>
            <button className="primary-button" disabled={busy}>{busy?'Publishing…':<><Plus size={16}/> Publish project</>}</button>
          </form>
          <div className="admin-list"><h3>Published projects ({projects.length})</h3>{projects.map(p=><div className="admin-row" key={p.id}><img src={p.image_url} alt=""/><span>{p.title}<small>{p.category}</small></span><button aria-label={`Delete ${p.title}`} onClick={()=>deleteProject(p)}><Trash2 size={16}/></button></div>)}</div>
        </>}
      {notice && <p className="notice">{notice}</p>}
    </section></div>}
  </div>;
}